<?php
$conf=array(
	"admin_user" => "admin",
	"admin_pwd" => "admin888",
);
?>