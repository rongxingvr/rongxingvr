<?php
 $yzm =  array (
  'key' => '填写你的KEY',
  'fdhost' => '',
  'api1' => '',
  'right_wenzi' => '融兴视频解析',
  'right_link' => 'https://vip.rongxingvr.cn',
  'title' => '融兴视频解析系统',
  'url_wenzi' => '<p>请填入视频URL地址进行测试</p><p>若视频URL有类似html?xxxxxxxx，请将问号及后面的部分删除</p>',
  'referer_wenzi' => '触发了防盗链！不可盗用测试解析域名',
  'error_wenzi' => '加载失败，请检查视频链接或稍候再等一下哈~~',
  'footer' => '',
  'danmuon' => 'on',
  'public_dmku' => 'on',
  'color' => '#ff6429',
  'logo' => 'https://cdn.jsdelivr.net/gh/rongxingvr/rongxingvr@main/jxlogo.png',
  'logo_width_height' => '100,50',
  'loading_on' => 'on',
  'loading_pic' => 'https://cdn.jsdelivr.net/gh/rongxingvr/rongxingvr@main/hongkongad2.jpg',
  'loading_width_height' => '800,500',
  'loading_color' => '#000',
  'trytime' => '3',
  'sendtime' => '1',
  'dmrule' => '',
  'pbgjz' => 'SB,垃圾,,草,操,妈,逼,滚,网址,网站,支付宝,企,关注,wx,微信,qq,QQ',
  'ads' => 
  array (
    'state' => 'on',
    'set' => 
    array (
      'state' => '2',
      'group' => 'null',
      'pic' => 
      array (
        'time' => '3',
        'img' => 'https://cdn.jsdelivr.net/gh/rongxingvr/rongxingvr@main/hongkongad2.jpg',
        'link' => 'https://idc.rongxingvr.cn/cart?fid=5',
      ),
      'vod' => 
      array (
        'url' => '/ad.mp4',
        'link' => '',
      ),
    ),
    'pause' => 
    array (
      'state' => 'on',
      'pic' => 'https://cdn.jsdelivr.net/gh/rongxingvr/rongxingvr@main/hongkongad2.jpg',
      'link' => 'https://idc.rongxingvr.cn/cart?fid=5',
    ),
  ),
);
?>