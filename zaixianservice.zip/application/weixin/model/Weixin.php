<?php
/**
 * Created by PhpStorm.
 * User: Andy
 * Date: 2020/2/18
 * Time: 14:54
 */
namespace app\weixin\model;

use think\Model;

class Weixin extends Model
{
    protected $field = true;

    protected $table = 'wolive_weixin';

}