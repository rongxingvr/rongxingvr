<?php
/**
 * Created by PhpStorm.
 * User: Andy
 * Date: 2020/3/19
 * Time: 10:27
 */
namespace app\common\lib\cloud;

use think\Exception;

class CloudException extends Exception
{

}