<?php
/**
 * @copyright ©2020 爱客服PHP在线客服系统
 * Created by PhpStorm.
 * User: Andy - Wangjie
 * Date: 2020/6/17
 * Time: 16:50
 */

namespace app\common\lib\storage;

class StorageException extends \Exception
{

}