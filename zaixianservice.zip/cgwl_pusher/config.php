<?php
// 这里填写客服系统域名，前面带http://，用于pusher系统通知客服平台客户或者客服上下线
$domain = 'http://kf.domain.com';

// App_key，客服系统与pusher通讯的key
$app_key = '3331333731383036';

// App_secret，客服系统与pusher通讯的密钥
$app_secret = '6842a54e4aab6e22bf368e5b7291efdf';

// App id
$app_id = 232;

// websocket 端口，客服系统网页会连这个端口
$websocket_port = 9090;

// Api 端口，用于后端与pusher通讯
$api_port = 2080;

