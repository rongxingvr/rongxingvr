
            /**
             *
             * wolive 浮层版 客服咨询js
             * [wolive description]
             * @return {[type]} [description]
             */

                var head = document.getElementsByTagName('head')[0];
                var link = document.createElement('link');
                    link.type='text/css';
                    link.rel = 'stylesheet';
                    link.href ='/assets/css/index/cgwl_online.css';
                    head.appendChild(link);

                var cgwl ={
                     visiter_id:'',
                     visiter_name:'',
                     avatar:'',
                     product:'',
                     open:function(){
                        var d =document.getElementById('wolive-box');
                        if(!d){
                            var div =document.createElement('div');
                            div.id ="cgwl-kefu";
                            div.className +='cgwl-form';
                            document.body.appendChild(div);
                            var w =document.getElementById('cgwl-kefu');
                            w.innerHTML=' <i class="cgwl-icon"></i><p class="cgwl-item zidong" onclick="cgwl.connenct(0)" >在线咨询</p><p class="cgwl-item" onclick="cgwl.connenct(3)">售前客服</p><p class="cgwl-item" onclick="cgwl.connenct(4)">售后客服</p><p class="cgwl-item" onclick="cgwl.connenct(5)">技术客服</p><p class="cgwl-item" onclick="cgwl.connenct(6)">财务</p>';
                        }
                     },
                     connenct:function(groupid){
                      var id =groupid;
                      var web =encodeURI('/layer?visiter_id='+this.visiter_id+'&visiter_name='+this.visiter_name+'&avatar='+this.avatar+'&business_id=1&groupid='+groupid+'&product='+this.product);
                      
                      var moblieweb = encodeURI('/mobile/index/home?visiter_id='+this.visiter_id+'&visiter_name='+this.visiter_name+'&avatar='+this.avatar+'&business_id=1&groupid='+groupid+'&product='+this.product);

                       if ((navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i))) {
                        
                         window.open(moblieweb); 
                       
                       }else{

                       var s =document.getElementById('wolive-talk');
                        
                       if(!s){

                            var div = document.createElement('div');
                            div.id ="wolive-talk";
                            div.name=id;
                            document.body.appendChild(div);
                            div.innerHTML='<i class="cgwl-close" onclick="cgwl.narrow()"></i><iframe id="wolive-iframe" src="'+web+'"></iframe>'
                          
                        }else{
                           
                            var title =s.name;
                            if(title == groupid){
                                s.style ='display:block';
                            }else{
                                s.parentNode.removeChild(s);
                                cgwl.connenct(groupid); 
                            }
                        }
                      }
                     },
                     narrow:function(){
                        document.getElementById('wolive-talk').style="display:none";
                     }
                }

                window.onload =cgwl.open();

        