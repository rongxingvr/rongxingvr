<?php
error_reporting(0);

include ('asset/data.php');
$url = $_GET['url'];


if($url==''){

	echo("<meta name=\"robots\" content=\"noarchive\"><title>" . $yzm["link"] . "</title><link rel=\"shortcut icon\" href=\"/favicon.ico\" type=\"image/x-icon\">
                	  <style>h1{color:#FFFFFF; text-align:center; font-family: Microsoft Jhenghei;}p{color:#CCCCCC; font-size: 1.2rem;text-align:center;font-family: Microsoft Jhenghei;}</style>
                	  <body bgcolor=\"#000000\"><table width=\"100%\" height=\"100%\" align=\"center\"><td align=\"center\"><h1>" . $yzm["url_wenzi"] . "</font><font size=\"2\"></font></p></table></body>
              ");
	die();
}
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: x-requested-with,content-type");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Origin: *");
header("Cache-Control: no-cache, no-store, max-age=0, must-revalidate");
header("Connection: keep-alive");


if ($yzm["fdhost_on"] == "on" & !$yzm["fdhost"]=="") {
	define('REFERER_URL', $yzm["fdhost"]);
	$uriarr = parse_url($_SERVER['HTTP_REFERER']);
	$host1 = $uriarr['host'];
	$ymarr = explode(",",REFERER_URL);

	$urlArr = explode("//", $_SERVER["HTTP_REFERER"])[1];
	$host = explode("/", $urlArr)[0];
	$host = explode(":", $host)[0];
	$fdhost = explode(",", $yzm["fdhost"]);
	$localhost = explode(":", $_SERVER["HTTP_HOST"])[0];
	$fdhost[] = $localhost;
	if ($yzm["blank_referer"] == "on") {
		$fdhost[] = "";
	}
	if (!in_array($host, $fdhost)) {
		exit("<html><meta name=\"robots\" content=\"noarchive\">\r\n                    \t  <style>h1{color:#FFFFFF; text-align:center; font-family: Microsoft Jhenghei;}p{color:#CCCCCC; font-size: 1.2rem;text-align:center;font-family: Microsoft Jhenghei;}</style>\r\n                    \t  <body bgcolor=\"#000000\"><table width=\"100%\" height=\"100%\" align=\"center\"><td align=\"center\"><h1>" . $yzm["referer_wenzi"] . "</font><font size=\"2\"></font></p></table><script src=\"./js/jquery.min.js\"></script><script>\$(\"#my-loading\", parent.document).remove();</script></body>\r\n                  </html>");
	}
}

if (strpos($url, "www.bilibili.com") && wp_is_mobile() || strpos($url, "m.bilibili.com")) {
	$url = str_replace("m.bilibili.com", "www.bilibili.com", $url);
	$url = str_replace("www.bilibili.com", "m_www.bilibili.com", $url);
}
if (strpos($url, "www.mgtv.com") && wp_is_mobile()) {
	$url = str_replace("www.mgtv.com", "m_www.mgtv.com", $url);
}
$key1 = "https://fast.rongxingvr.cn:8866/api/?key=".$yzm['jx']['set']['key1']."&url=";//融兴解析

if(strpos($url,'m3u8')==false or strpos($url,'mp4')==false){
	if ($yzm['jx']['state']){
		if($yzm['jx']['set']['group'] == '1'){
			$data = file_get_contents($key1.$url);
			$urls = json_decode($data, true);
			if($urls['code']=='200'){
				$url = $urls['url'];
				$metareferer = isset($urls['metareferer']) ?$urls['metareferer']: '';
				if ($metareferer == "") {
					$metareferer = "never";
				}
			}else{ 
				$url = jx($yzm['jx']['set']['bak1'],$url);
			}
			$metareferer = isset($urls['metareferer']) ?$urls['metareferer']: '';
			if ($metareferer == "") {
				$metareferer = "never";
			}else{ 
				$url = jx($yzm['jx']['set']['bak2'],$url);
			}
			$metareferer = isset($urls['metareferer']) ?$urls['metareferer']: '';
			if ($metareferer == "") {
				$metareferer = "never";
			}
		}else{ 
				$url = jx($yzm['jx']['set']['bak3'],$url);
			}
			$metareferer = isset($urls['metareferer']) ?$urls['metareferer']: '';
			if ($metareferer == "") {
				$metareferer = "never";
			}
		}else{
				$url = jx($yzm['jx']['set']['bak4'],$url);
		}
		$metareferer = isset($urls['metareferer']) ?$urls['metareferer']: '';
			if ($metareferer == "") {
				$metareferer = "never";
			}
	}

function jx($key,$link){
	$data = file_get_contents($key.$link);
	$urls = json_decode($data, true);
	if($urls['code']=='200'){
		$url = $urls['url'];
		$metareferer = isset($urls['metareferer']) ?$urls['metareferer']: '';
		if ($metareferer == "") {
			$metareferer = "never";
		}
	}else{ 
		$url = $link;
	}
	return $url;
}
function wp_is_mobile()
{
	static $is_mobile;
	if (isset($is_mobile)) {
		return $is_mobile;
	}
	if (empty($_SERVER["HTTP_USER_AGENT"])) {
		$is_mobile = false;
	} else {
		if (strpos($_SERVER["HTTP_USER_AGENT"], "Mobile") !== false || strpos($_SERVER["HTTP_USER_AGENT"], "Android") !== false || strpos($_SERVER["HTTP_USER_AGENT"], "Silk/") !== false || strpos($_SERVER["HTTP_USER_AGENT"], "Kindle") !== false || strpos($_SERVER["HTTP_USER_AGENT"], "BlackBerry") !== false || strpos($_SERVER["HTTP_USER_AGENT"], "Opera Mini") !== false || strpos($_SERVER["HTTP_USER_AGENT"], "Opera Mobi") !== false) {
			$is_mobile = true;
		} else {
			$is_mobile = false;
		}
	}
	return $is_mobile;
}
function geturldata($url){ 
	$ch = curl_init();
	curl_setopt ($ch, CURLOPT_URL, $url);
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER,1); 
	curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT,10);
	$content = curl_exec($ch); 
	return $content; 
} 