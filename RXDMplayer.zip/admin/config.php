<?php
 $yzm =  array (
 'adminpass' => 'admin888',//后台密码
 'tips' =>               //出场弹幕提示
  array (
    'time' => '6',
    'color' => '#fb7299',
    'text' => '官方解析祝大家万事如意',
  ),
  'ok' => '0',         //接口防窥
  );
?>