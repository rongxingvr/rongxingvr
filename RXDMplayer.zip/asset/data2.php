<?php
 $yzm =  array (
  'title' => '融兴视频解析',
  'url_wenzi' => '请填入视频URL地址进行测试   若视频URL有类似html?xxxxxxxx   请将问号及后面的部分删除',
);
?>