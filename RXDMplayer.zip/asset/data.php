<?php
 $yzm =  array (
  'danmuon' => 'on',
  'color' => '#00a1d6',
  'tip' => ' 请文明用语',
  'logo' => 'https://cdn.jsdelivr.net/gh/rongxingvr/rongxingvr@main/jxlogo.png',
  'waittime' => '10',
  'sendtime' => '1',
  'dmrule' => '',
  'url_wenzi' => '请粘贴视频链接到地址栏',
  'pbgjz' => 'ABCDEFGHIJKMNOPQ,草,操,妈,逼,滚,网址,网站,支付宝,企,关注,wx,微信,qq,QQ',
  'link' => '融兴视频解析',
  'ads' => 
  array (
    'set' => 
    array (
      'state' => '2',
      'group' => '3',
      'pic' => 
      array (
        'time' => '3',
        'img' => 'https://cdn.jsdelivr.net/gh/rongxingvr/rongxingvr@main/hongkongad2.jpg',
        'link' => 'https://idc.rongxingvr.cn/cart?fid=5',
      ),
      'vod' => 
      array (
        'url' => '',
        'link' => '',
      ),
    ),
    'pause' => 
    array (
      'state' => 'on',
      'pic' => 'https://cdn.jsdelivr.net/gh/rongxingvr/rongxingvr@main/hongkongad2.jpg',
      'link' => 'https://idc.rongxingvr.cn/cart?fid=5',
    ),
  ),
  'jx' => 
  array (
    'state' => 'on',
    'set' => 
    array (
      'group' => '1',
      'key1' => '',
      'bak1' => '',
      'bak2' => '',
      'bak3' => '',
      'bak4' => '',
    ),
  ),
  'referer_wenzi' => '嘎哈，想盗用接口？跟你讲哈，IP记下了~~~',
  'blank_referer' => 'on',
  'fdhost' => '',
);
?>