<?php 
error_reporting(0); //抑制所有错误信息
require 'user.php';//用户配置
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: x-requested-with,content-type");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Origin: *");
header("Cache-Control: no-cache, no-store, max-age=0, must-revalidate");
header("Connection: keep-alive");
header("Transfer-Encoding: chunked");

if ($fdhost_on == "1") {
    /** 切割地址栏参数url */
    $urlArr = explode("//", $_SERVER['HTTP_REFERER'])[1];
    
    /** 切割出域名 */
    $host  = explode("/", $urlArr)[0];
    
    /** 去掉端口 */
    $host  = explode(":", $host)[0];
    //判断域名是否在列表中
    if(!in_array($host, $fdhost)){
        exit($errorRefererHtml);
    }
}


/**  判断metareferer的类型，并且插入到头部 */
$url = preg_replace('/url=/','',$_SERVER['QUERY_STRING'],1);

if (empty($url)) {
    
   exit($html);
         
}

echo('
    <!DOCTYPE html><html><head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta charset="UTF-8">
    <title>'.$title.'</title>
        <link rel="shortcut icon" href="//q1.qlogo.cn/g?b=qq&nk=495040644&s=640" />
');


echo ('
<style>
    #loading-box {
        background: # !important;
    }
    #my-loading{
        width: 100%;
        height: 100%;
        position: absolute;
        left: 0;
        top: 0;
        z-index: 99999;
        background-color:'.$loading_color.';
    }
    .loading-text{
        position: absolute;
        left: 35px;
        bottom: 7%;
        font-size: 0.5rem;
        color:#999;
    }
    .iframeStyle{
        width: 100%;
        height: 100%;
        border: 0px;
    }
    .loading .pic{
        background: url('.$loading_pic.') no-repeat!important;
        background-size: '.$loading_pic_width.'px !important;
        width: '.$loading_pic_width.'px;
        height: '.$loading_pic_height.'px;
        position: absolute;
        pointer-events: none;
        border: 0;
        border-color: unset;
        opacity: 1;
        border-radius: 0;
        -moz-animation: spinoffPulse .9s infinite linear;
        -webkit-animation: unset;
        background-size: 100%;
        top: 50%;
        left: 50%;
        transform: translate3d(-50%,-50%,0px);
    }
    
    body, html {
    font: 24px "Microsoft YaHei", Arial, Lucida Grande, Tahoma, sans-serif;
    width: 100%;
    height: 100%;
    padding: 0;
    margin: 0;
    overflow-x: hidden;
    overflow-y: hidden;
    }
    
    * {
    margin: 0;
    padding: 0;
    font-style: normal;
    font-weight: normal;
    }
</style>');


echo('</head><body>
        <div class="loading" id="my-loading">
            <div class="pic"></div>
        </div>');
        
    if($url){ 
        echo('
            <iframe src="analysis.php?v='.$url.'" class="iframeStyle" id="myiframe" ></iframe>'); 
    }
       
echo('</body></html>');
 
 ?>