<?php
error_reporting(0); //抑制所有错误信息
require 'user.php';//用户配置
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: x-requested-with,content-type");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Origin: *");
header("Cache-Control: no-cache, no-store, max-age=0, must-revalidate");
header("Connection: keep-alive");
header("Transfer-Encoding: chunked");

if ($fdhost_on == "1") {
    /** 切割地址栏参数url */
    $urlArr = explode("//", $_SERVER['HTTP_REFERER'])[1];
    
    //添加本机域名
    $localhost = explode(":", $_SERVER['HTTP_HOST'])[0];
    $fdhost[] = $localhost;
    /** 切割出域名 */
    $host  = explode("/", $urlArr)[0];
    
    /** 去掉端口 */
    $host  = explode(":", $host)[0];
    //判断域名是否在列表中
    if(!in_array($host, $fdhost)){
        exit($errorRefererHtml);
    }
}

function get_url($url, $type = 0, $post_data = '', $ua = '' , $cookie = '',  $redirect = true){
	$refere = "https://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	$header = array("Referer:".$refere,"User-Agent:".$_SERVER['HTTP_USER_AGENT']);
	// 初始化cURL
	$curl = curl_init();
	// 设置网址
	curl_setopt($curl,CURLOPT_URL, $url);
	// 设置UA
	if(empty($ua) == false){
		$header[] = 'User-Agent:'.$_SERVER['HTTP_USER_AGENT'];
	}
	// 设置Cookie
	if(empty($cookie) == false){
		$header[] = 'Cookie:'.$cookie;
	}
	// 设置请求头
	if(empty($ua) == false or empty($cookie) == false or empty($header) == false){
		curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
	}
	// 设置POST数据
	if($type == 1){
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
	}
	// 设置重定向
	if($redirect == false){
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true); 
	}

	// 过SSL验证证书
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
	// 将头部作为数据流输出
	curl_setopt($curl, CURLOPT_HEADER, false);
	// 设置以变量形式存储返回数据
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	// 请求并存储数据
	$return = curl_exec($curl);
	// 分割头部和身体
	if(curl_getinfo($curl, CURLINFO_HTTP_CODE) == '200'){
		$return_header_size = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
		$return_header = substr($return, 0, $return_header_size);
		$return_data = substr($return, $return_header_size);
	}
	// 关闭cURL
	curl_close($curl);
	// 返回数据
	return $return;
}

function wp_is_mobile() {
 static $is_mobile = null;
 
 if ( isset( $is_mobile ) ) {
  return $is_mobile;
 }
 
 if ( empty($_SERVER['HTTP_USER_AGENT']) ) {
  $is_mobile = false;
 } elseif ( strpos($_SERVER['HTTP_USER_AGENT'], 'Mobile') !== false
  || strpos($_SERVER['HTTP_USER_AGENT'], 'Android') !== false
  || strpos($_SERVER['HTTP_USER_AGENT'], 'Silk/') !== false
  || strpos($_SERVER['HTTP_USER_AGENT'], 'Kindle') !== false
  || strpos($_SERVER['HTTP_USER_AGENT'], 'BlackBerry') !== false
  || strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mini') !== false
  || strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mobi') !== false ) {
   $is_mobile = true;
 } else {
  $is_mobile = false;
 }
 
 return $is_mobile;
}


$next = @$_GET['next'];
$url=preg_replace('/v=/','',$_SERVER['QUERY_STRING'],1);

if (strpos($url, 'www.bilibili.com') && wp_is_mobile() || strpos($url, 'm.bilibili.com')) {
    $url = str_replace('m.bilibili.com','www.bilibili.com',$url);
    $url = str_replace('www.bilibili.com','m_www.bilibili.com',$url);
}
if (strpos($url, 'www.mgtv.com') && wp_is_mobile()) {
    $url = str_replace('www.mgtv.com','m_www.mgtv.com',$url);
}
if (empty($url)) {
  exit($html);
  } else {
	$preg = "/^http(s)?:\\/\\/.+/";
	$type = '';
	if(preg_match($preg,$url)){//判断是否为网址
	if(strstr($url, '.m3u8')==true || strstr($url, '.mp4')==true || strstr($url, 'pan.cuan.la')==true || strstr($url, '.flv')==true){
	$type = $url;//获取播放链接
	$metareferer = "never";
	}
	}
	if($type == ''){//接口一
    $fh = get_url("https://lgjx.rongxingvr.cn:8866/api/?key=".$key."&ip=".$_SERVER['REMOTE_ADDR']."&url=".$url);
    $jx = json_decode($fh, true);
	$type = $jx['url'];
	$metareferer = $jx['metareferer'];
	if($metareferer == ""){
        $metareferer = "never";
    }
	}
	
	if($type == ''){//接口一为空调用接口二
    $fh = get_url($api1.$url);
    $jx = json_decode($fh, true);
	$type = $jx['url'];
	$metareferer = $jx['metareferer'];
    if($metareferer == ""){
        $metareferer = "never";
    }
	}
	
	if($type == ''){//接口二为空调用接口三
    $fh = get_url($api2.$url);
    $jx = json_decode($fh, true);
	$type = $jx['url'];
	$metareferer = $jx['metareferer'];
    if($metareferer == ""){
        $metareferer = "never";
    }
	}
}
if($type == ''){
	exit('<html><meta name="robots" content="noarchive">
<style>h1{color:#FFFFFF; text-align:center; font-family: Microsoft Jhenghei;}p{color:#CCCCCC; font-size: 1.2rem;text-align:center;font-family: Microsoft Jhenghei;}</style>
<body bgcolor="#000000"><table width="100%" height="100%" align="center"><td align="center"><h1>解析失败，请稍后再试~</font><font size="2"></font></p></table></body><script src="./js/jquery.min.js"></script><script>$("#my-loading", parent.document).remove();</script></html>');
}
if($h5 != "1"){
    include "./html/dplayer.htm";
}else{
    if(!wp_is_mobile()){
    $file="./html/dplayer.htm";
        include $file; exit;
    }else{
        include "./html/h5player.htm"; exit;
    }
}

 ?>